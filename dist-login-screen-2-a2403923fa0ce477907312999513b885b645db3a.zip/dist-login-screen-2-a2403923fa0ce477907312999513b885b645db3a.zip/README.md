# Login Screen

- Category: Web
- Solves: 
  - Flag 1: All: 217 / 389 (score > 100)
  - Flag 2: All: 14 / 389 (score > 100)
## Description
Welcome to my Login Screen! This is your go-to space for important announcements, upcoming events, helpful resources, and community updates. Whether you're looking for deadlines, meeting times, or opportunities to get involved, you'll find all the essential information posted here. Be sure to check back regularly to stay informed and connected!

## Flag 1 Solution
TBD

## Flag 2 Solution
TBD